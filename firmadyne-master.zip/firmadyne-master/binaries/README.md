Binary files used by the FIRMADYNE framework should be placed here. These include:

* console
   * `console.armel`
   * `console.mipseb`
   * `console.mipsel`

* libnvram
   * `libnvram.so.armel`
   * `libnvram.so.mipseb`
   * `libnvram.so.mipsel`

* kernel
   * `zImage.armel`
   * `vmlinux.mipseb`
   * `vmlinux.mipsel`
