Tarballs of extracted filesystems firmware images should be placed here.
